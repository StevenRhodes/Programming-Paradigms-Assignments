/* Question #5
Name: Steven Rhodes
ID: 100819007
*/

%Database

element(air).
element(earth).
element(fire).
element(water).

compound(animal,[life,forest]).
compound(bird,[animal,air]).
compound(cloud, [water,air]).
compound(fish,[life,ocean]).
compound(forest, [plant,plant]).
compound(life, [lightning,ocean,volcano]).
compound(lightning, [storm,cloud,earth]).
compound(ocean, [water,water,water]).
compound(plant, [earth,life]).
compound(rain, [cloud,water]).
compound(storm, [cloud,wind]).
compound(volcano, [fire,earth]).
compound(wind, [air,air]).


%HELPFUNCTIONS

list([]).
list([_|L]):-
	list(L).

join([], L, L).

join([H|L1], L2, [H|L3]):-
    join(L1, L2, L3).

treeFlat([],[]).

treeFlat(X, [X|[]]):- 
	not(list(X)).

treeFlat([H|T], L):- 
	treeFlat(H,Temp1),
	treeFlat(T,Temp2),
	join(Temp1,Temp2, L).


%---------------------------------------
%PART-A

%checks if elements and returns a list of them
%baseCase
getElements([]).

%recursive
getElements([H|T]):-
	element(H),
	getElements(T).

%breaks compound elements down to elements
%baseCase
breakCompound([], []).

%if head is an element, add to final list, and keep cdring through compound
breakCompound([H|T], [H|T2]):-
	element(H),
	breakCompound(T, T2).

%if head is compound then simplify that as with initial compound
breakCompound([H|T], [H2|T2]):-
	compound(H,_), 
	simplify(H,H2), 
	breakCompound(T,T2).
	
%case 1: if Thing = an element
simplify(Element, [Element|[]]):- 
	element(Element).
	
%case 2: if compound has elements, get elements
simplify(Things, Elements):-
	compound(Things, Elements),
	getElements(Elements).
	%treeFlat(Elements).

%case 3: if compound has more compounds, break them down	
simplify(Things, Elements):-
	compound(Things, R),
	not(getElements(R)),
	breakCompound(R,T),
	treeFlat(T,Elements).
	

%-------------------------------------------------------------------
	


%b	

%break down C to look for T(which a compound)
checkDecendantCompounds( [H|_] , R):-
	makes(R,H).

checkDecendantCompounds([H|T] , R):-
	not(makes(R,H)),
	checkDecendantCompounds( T ,R).


	
%Case #1: if Thing is an element
makes(T , C):-
	element(T),
	simplify(C, R),
	member(T, R).
	
%Case #2: if compound, but 1 degree away
makes(T, C):-
	compound(T, _),
	compound(C, R),
	member(T,R).

%Case #3: if compound but multiple degrees away
makes(T, C):-
	compound(T, _),
	compound(C, R),
	not(member(T,R)),
	checkDecendantCompounds(R , T).
	

	
	
	