/* COMP 3007 Assignment #5

Name: Steven Rhodes
ID: 100819007

Question #1 

*/

%a)

male(steve).
male(roger).
male(donald).
male(colin).
male(david).
%yoda is an ancestor
male(yoda).
female(yodamom).
female(mei).
female(jaqueline).
female(kelly).
female(annie).
female(jessica).
father(donald, steve).
father(donald, roger).
father(donald, annie).
father(steve, david).
father(steve, abigail).
father(yoda,donald).
mother(kelly, steve).
mother(kelly, roger).
mother(kelly,annie).
mother(mei,jaqueline).
mother(mei,jessica).
mother(jaqueline,david).
mother(jaqueline, abigail).
mother(yodamom,yoda).
marriedTo(kelly, donald).

%predicate to marry two people together
married(X,Y):-marriedTo(X,Y),!.
married(X,Y):-marriedTo(Y,X).

/*Also could have had seperate married() facts for each direction
i.e married(donald,kelly) and married(kelly, donald)
*/

/* ----------------------------------------------------------------- */

%b

parent(X,Y):-father(X,Y),!.
parent(X,Y):-mother(X,Y),!.

is_father(X):-male(X), parent(X,_).
is_mother(X):-parent(X,_), female(X).

%works both ways 
brother(X,Y):-parent(Z,X), parent(Z,Y), male(X).
sister(X,Y):-parent(Z,X), parent(Z,Y), female(X).

aunt(X,Y):-sister(X,Z), parent(Z,Y).
uncle(X,Y):-brother(X,Z), parent(Z,Y).

grandmother(X,Y):- mother(X,Z), parent(Z,Y).
grandfather(X,Y):- father(X,Z), parent(Z,Y).

%assumption: ancestor is anyone from your parents, grandparents, great-grandparents, and so on...
ancestor(X,Y):- parent(X,Y),!.
ancestor(X,Y):- parent(X, Z), ancestor(Z, Y),!.
