% Question #2:
/*
Name: Steven Rhodes
ID: 100819007
*/

% Database %
%player(name(First,Last),team(City),pos(Position),stats(Goals,Assists,Shots))
player(name(alex,ovechkin),team(was),pos(lw),stats(51,38,338)).
player(name(marcus,pettersson),team(pit),pos(d),stats(2,23,87)).
player(name(kevin,fiala),team(min),pos(lw),stats(13,26,174)).
player(name(ryan,hartman),team(min),pos(rw),stats(12,14,145)).
player(name(leon,driasaitl),team(edm),pos(c),stats(50,55,231)).
player(name(john,tavares),team(tor),pos(c),stats(47,41,286)).
player(name(steven,stamkos),team(tb),pos(c),stats(45,53,234)).
player(name(nikita,kucherov),team(tb),pos(rw),stats(41,87,246)).
player(name(nathan,mackinnon),team(col),pos(c),stats(41,58,365)).
player(name(alex,debrincat),team(chi),pos(rw),stats(41,35,220)).
player(name(jake,guentzel),team(pit),pos(lw),stats(40,36,227)).
player(name(jeff,skinner),team(buf),pos(lw),stats(40,23,268)).
player(name(mark,scheifele),team(wpg),pos(c),stats(38,46,199)).
player(name(johnny,gaudreau),team(cgy),pos(lw),stats(36,63,245)).
player(name(mike,hoffman),team(fla),pos(lw),stats(36,34,253)).
player(name(aleksander,barkov),team(fla),pos(c),stats(35,61,206)).
player(name(morgan,rielly),team(tor),pos(d),stats(20,52,223)).
player(name(brent,burns),team(sj),pos(d),stats(16,67,300)).
player(name(patrick,kane),team(chi),pos(rw),stats(44,66,341)).
player(name(john,tavares),team(tor),pos(c),stats(47,41,286)).

/*
a) Answer: player(name(mike, hoffman), team(TEAM), _, _).

	?- player(name(mike, hoffman), team(TEAM), _, _). %expected: TEAM = fla.
	TEAM = fla.

--------------------------------------------------------------------------------

b) Answer: player(name(_, Lastname), _, _, stats(_, X, _)), X>=52.
	
	?- player(name(_, Lastname), _, _, stats(_, X, _)), X>=52. % expected: the output shown, too long...
	Lastname = driasaitl,
	X = 55 ;
	Lastname = stamkos,
	X = 53 ;
	Lastname = kucherov,
	X = 87 ;
	Lastname = mackinnon,
	X = 58 ;
	Lastname = gaudreau,
	X = 63 ;
	Lastname = barkov,
	X = 61 ;
	Lastname = rielly,
	X = 52 ;
	Lastname = burns,
	X = 67 ;
	Lastname = kane,
	X = 66 ;

------------------------------------------------------------------------------------

c) Answer: player(name(Firstname, Lastname), _, pos(c), _).
	
	?- player(name(Firstname, Lastname), _, pos(c), _).
	Firstname = leon,
	Lastname = driasaitl ;
	Firstname = john,
	Lastname = tavares ;
	Firstname = steven,
	Lastname = stamkos ;
	Firstname = nathan,
	Lastname = mackinnon ;
	Firstname = mark,
	Lastname = scheifele ;
	Firstname = aleksander,
	Lastname = barkov ;
	Firstname = john,
	Lastname = tavares.

-------------------------------------------------------------------------------------

d) Answer: player(name(john, _), team(Team), _, _).
	
	?- player(name(john, _), team(Team), _, _). %expected: duplicates of John Tavares, from Toronto
	Team = tor ;
	Team = tor.

--------------------------------------------------------------------------------------------

e) Answer: player(name(Firstname, Lastname), team(X), _, _), player(name(FirstnameTwo, LastnameTwo), team(Y), _, _), X = Y, Firstname\=FirstnameTwo, Lastname\=LastnameTwo.

	?- player(name(Firstname, Lastname), team(X), _, _), player(name(FirstnameTwo, LastnameTwo), team(Y), _, _), X = Y, Firstname\=FirstnameTwo, Lastname\=LastnameTwo.
	Firstname = marcus,
	Lastname = pettersson,
	X = Y, Y = pit,
	FirstnameTwo = jake,
	LastnameTwo = guentzel ;
	Firstname = kevin,
	Lastname = fiala,
	X = Y, Y = min,
	FirstnameTwo = ryan,
	LastnameTwo = hartman ;
	Firstname = ryan,
	Lastname = hartman,
	X = Y, Y = min,
	FirstnameTwo = kevin,
	LastnameTwo = fiala ;
	Firstname = john,
	Lastname = tavares,
	X = Y, Y = tor,
	FirstnameTwo = morgan,
	LastnameTwo = rielly ;
	Firstname = steven,
	Lastname = stamkos,
	X = Y, Y = tb,
	FirstnameTwo = nikita,
	LastnameTwo = kucherov ;
	Firstname = nikita,
	Lastname = kucherov,
	X = Y, Y = tb,
	FirstnameTwo = steven,
	LastnameTwo = stamkos ;
	Firstname = alex,
	Lastname = debrincat,
	X = Y, Y = chi,
	FirstnameTwo = patrick,
	LastnameTwo = kane ;
	Firstname = jake,
	Lastname = guentzel,
	X = Y, Y = pit,
	FirstnameTwo = marcus,
	LastnameTwo = pettersson ;
	Firstname = mike,
	Lastname = hoffman,
	X = Y, Y = fla,
	FirstnameTwo = aleksander,
	LastnameTwo = barkov ;
	Firstname = aleksander,
	Lastname = barkov,
	X = Y, Y = fla,
	FirstnameTwo = mike,
	LastnameTwo = hoffman ;
	Firstname = morgan,
	Lastname = rielly,
	X = Y, Y = tor,
	FirstnameTwo = john,
	LastnameTwo = tavares ;
	Firstname = morgan,
	Lastname = rielly,
	X = Y, Y = tor,
	FirstnameTwo = john,
	LastnameTwo = tavares ;
	Firstname = patrick,
	Lastname = kane,
	X = Y, Y = chi,
	FirstnameTwo = alex,
	LastnameTwo = debrincat ;
	Firstname = john,
	Lastname = tavares,
	X = Y, Y = tor,
	FirstnameTwo = morgan,
	LastnameTwo = rielly ;
	
-------------------------------------------------------------------------------------	

f)Answer: player(name(Firstname, Lastname), _, _, stats(Goals, Assists, _)), Goals + Assists < 100.

	?- player(name(Firstname, Lastname), _, _, stats(Goals, Assists, _)), Goals + Assists < 100.
	Firstname = alex,
	Lastname = ovechkin,
	Goals = 51,
	Assists = 38 ;
	Firstname = marcus,
	Lastname = pettersson,
	Goals = 2,
	Assists = 23 ;
	Firstname = kevin,
	Lastname = fiala,
	Goals = 13,
	Assists = 26 ;
	Firstname = ryan,
	Lastname = hartman,
	Goals = 12,
	Assists = 14 ;
	Firstname = john,
	Lastname = tavares,
	Goals = 47,
	Assists = 41 ;
	Firstname = steven,
	Lastname = stamkos,
	Goals = 45,
	Assists = 53 ;
	Firstname = nathan,
	Lastname = mackinnon,
	Goals = 41,
	Assists = 58 ;
	Firstname = alex,
	Lastname = debrincat,
	Goals = 41,
	Assists = 35 ;
	Firstname = jake,
	Lastname = guentzel,
	Goals = 40,
	Assists = 36 ;
	Firstname = jeff,
	Lastname = skinner,
	Goals = 40,
	Assists = 23 ;
	Firstname = mark,
	Lastname = scheifele,
	Goals = 38,
	Assists = 46 ;
	Firstname = johnny,
	Lastname = gaudreau,
	Goals = 36,
	Assists = 63 ;
	Firstname = mike,
	Lastname = hoffman,
	Goals = 36,
	Assists = 34 ;
	Firstname = aleksander,
	Lastname = barkov,
	Goals = 35,
	Assists = 61 ;
	Firstname = morgan,
	Lastname = rielly,
	Goals = 20,
	Assists = 52 ;
	Firstname = brent,
	Lastname = burns,
	Goals = 16,
	Assists = 67 ;
	Firstname = john,
	Lastname = tavares,
	Goals = 47,
	Assists = 41


-------------------------------------------------------------------------------------	
;sorry, comments are being weird, but it still works!!
%g)Answer: player(name(Firstname, Lastname), _ , _, stats(Goals, _ , Shots)), not((player(name(_, _), _ , _, stats(Goalstwo, _ , _)), Goalstwo>Goals)), Percentage is Goals /Shots,!.

	?- player(name(Firstname, Lastname), _ , _, stats(Goals, _ , Shots)), not((player(name(_, _), _ , _, stats(Goalstwo, _ , _)), Goalstwo>Goals)), Percentage is Goals /Shots,!.
	Firstname = alex,
	Lastname = ovechkin,
	Goals = 51,
	Shots = 338,
	Percentage = 0.15088757396449703.


---------------------------------------------------------------------------------------


h)Answer: player(name(Firstname, Lastname), _, pos(rw), stats(Goals1, _, Shots1)), Percentage1 is Goals1/Shots1, not((player(name(_, _), _, pos(rw), stats(Goals2, _, Shots2)), Percentage2 is Goals2/Shots2, Percentage2<Percentage1)),!.

	?- player(name(Firstname, Lastname), _, pos(rw), stats(Goals1, _, Shots1)), Percentage1 is Goals1/Shots1, not((player(name(_, _), _, pos(rw), stats(Goals2, _, Shots2)), Percentage2 is Goals2/Shots2, Percentage2<Percentage1)),!.
	Firstname = ryan,
	Lastname = hartman,
	Goals1 = 12,
	Shots1 = 145,
	Percentage1 = 0.08275862068965517.

*/