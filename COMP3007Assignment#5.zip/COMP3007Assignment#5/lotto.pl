/*Question #3

Name: Steven Rhodes
ID:100819007
*/

%a)
%outputs a random int in [min, max]
%if real float entered, output still displays an integer
%floats are truncated
random_int(Min, Max, R):- 
	Min =< Max,
	random(T), 
	R is(truncate(Min) +(truncate(T * ((truncate(Max) - truncate(Min)) + 1)))).





%b)
%return a range of numbers from A -> B
%base case
range(A,A, [A|[]]).

%recursive case
range(A, B, [A|T]):- 
	A=<B,
	A1 is A + 1,
	range(A1, B, T).
	




%c)
%remove the nth number from given list
%return removed item in Item
%return leftover list
%basecase
remove_nth(0, [H|T], H, T).

%recursiveCase:
remove_nth(N, [H|T], Item, [H|RT]):-
	N>0,
	length([H|T], Length),
	Length>0,
	N1 is N - 1,
	remove_nth(N1 , T , Item, RT).
	




%d)
%return N random items from a given List

%basecase
select_random(0, _, []).

%recursiveCase
select_random(N, [H|T], [HR|TR]):-
	N>0,
	length([H|T], Length),
	Length >= N,
	Indexlength is Length - 1,
	random_int(0, Indexlength, Int),
	N1 is N - 1,
	Length>0,
	remove_nth(Int, [H|T], HR, Newlist),
	select_random(N1, Newlist, TR).




%e)
%return 7 unique lotto numbers in [1,50] in sorted order
lotto(Return):-
	range(1, 50, L),
	select_random(7, L, R),
	sort(R, Return).



	
	
	
	