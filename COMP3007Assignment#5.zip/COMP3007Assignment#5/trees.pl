/* Question #4 
Name: Steven Rhodes
ID: 100819007
*/

%a)

%checks if L is a list
list([]).
list([_|L]):-
	list(L).
	
	
	
	
	
%b)
%helper function from class notes
join([], L, L).

join([H|L1], L2, [H|L3]):-
    join(L1, L2, L3).


%flatten a given tree
%baseCase
treeFlat([],[]).

%add X to return L if not a list
treeFlat(X, [X|[]]):- 
	not(list(X)).

%recursiveCase
treeFlat([H|T], L):- 
	treeFlat(H,Temp1),
	treeFlat(T,Temp2),
	join(Temp1,Temp2, L).





	
%c

%helper function from class notes
sum([],0).

sum([H|T], R):-
     number(H), 
     sum(T, PartialSum),
     R is PartialSum+H.
	 
%return sum of values in a tree
treeSum(T, S):-
	treeFlat(T, Flat),
	sum(Flat, S).
	